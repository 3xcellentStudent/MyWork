alert('mainCounter ("initial value", "final value", "duration", "element", "degree")')
function mainCounter(score, value, duration, elem, degree){
   let mainElem = document.querySelector('' + elem)
   let interval

   let strValue = value.toString().length
   let strDegree = degree.toString().length
   let mathStr = value / (1 + `${degree}`).toString.length

   funcCheck()

   function funcCheck(){
      if(strValue == strDegree){
         alert('value !== degree')
         return duration *= 0
      }
      else if(mathStr <= 1){
         alert('value !== degree')
         return duration *= 0
      }
      else if(score == 0){
         alert('0 invalid number, start with 1')
         return score = 0
      }
      else{
         console.log('code execution2')
         mainInterval()
         mainCountFunc()
      }
   }   
   
   function mainInterval(){
      if(Boolean(degree) == true){
         return interval = duration / (value / (1 + `${degree}`))
      }
      else if((score + 1) == value){
         return interval = duration / 2
      }
      else if(score > 0){
         return interval = duration / (value - score + 1)
      }
   }
   console.log(interval)
   function mainCountFunc(){
      let firstInterval = setInterval(function messege(){
         if(Boolean(degree) == true){
               if(score <= value / (1 + `${degree}`)){
                  return mainElem.innerHTML = ((score++) + `${degree}`)
               }
            console.log('true')
         }
         else if(score <= value){
               return mainElem.innerHTML = score++
         }
         clearInterval(firstInterval, console.log('finished'))
      }, interval)
   }
}
// mainCounter(1, 1000, 5000, '.counter', '00')
