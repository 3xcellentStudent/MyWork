let h2 = 'i\'m never alone'
let sect1_l_Text = 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Beatae voluptatem eius laudantium a vitae, dicta odio perferendis minus dolore asperiores!';

const body = document.querySelector('body')
const wrapper = document.createElement('div')
const container = document.createElement('div')
const h1 = document.createElement('h1')
const section1 = document.createElement('section')
const sect1Left = `
<div class="sect1_left" style="display: block; width: 40%">
   <h2 style="font-size: 32px; margin-top: 40px; margin-bottom: 20px">${h2}</h2>
   <p>${sect1_l_Text}</p>
</div>`;
const sect1Image = document.createElement('img')

sect1Image.src = "https://picsum.photos/240";
sect1Image.classList.add('sect_right_img')
wrapper.classList.add('main_wrapper')
container.classList.add('main_container')
section1.classList.add('section_1')

h1.append('Front-end')

body.appendChild(wrapper)
wrapper.appendChild(container)
container.appendChild(h1)
container.appendChild(section1)
section1.innerHTML = sect1Left//!!!!!!!!!! ("innerHTML")
section1.appendChild(sect1Image)

mainStyles = [
   {body: ['padding: 40px; font-size: 40px; letter-spacing: 0.04em']},
   {h1: ['font-size: 40px; text-align: center; color: #00FFA2']},
   {section1: ['display:flex; align-items: center; justify-content: space-between; margin: 80px auto 0 auto; width: 90%']},
   {sect1Image: ['display: block; width: 30%']},
   {paragraph1: ['font-size: 18px; color: #C0FFEE; font-style: italic']},
]

body.setAttribute('style', `${mainStyles[0].body}`)
h1.setAttribute('style', `${mainStyles[1].h1}`)
section1.setAttribute('style', `${mainStyles[2].section1}`)
sect1Image.setAttribute('style', `${mainStyles[3].sect1Image}`)

paragraph1 = document.querySelector('p')
console.log(paragraph1)
paragraph1.setAttribute('style', `${mainStyles[4].paragraph1}`)