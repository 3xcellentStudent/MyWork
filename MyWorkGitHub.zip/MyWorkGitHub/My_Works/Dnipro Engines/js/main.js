window.addEventListener('scroll', e => {
   let header = document.getElementById('header').classList
   let active_header = "scrolled"
   
   if(pageYOffset > 50) header.add(active_header)
   else header.remove(active_header)
})

function onEntry(entry) {
   entry.forEach(change => {
   if (change.isIntersecting) {
     change.target.classList.add('active');
       }
   else change.target.classList.remove('active')
     });
   }
   let options = { threshold: [0.5] };
   let observer = new IntersectionObserver(onEntry, options);
   let botLine2 = document.querySelectorAll('.botLine2');
   let bg_gear2 = document.querySelectorAll('.bg_gear2');
   let bg_polygon1 = document.querySelectorAll('.bg_polygon1');
   let bg_polygon2 = document.querySelectorAll('.bg_polygon2');
   let bg_gear1 = document.querySelectorAll('.bg_gear1');

   for (let elm of botLine2) {
     observer.observe(elm)
   };
   for (let elm of bg_gear2) {
      observer.observe(elm)
   };
   for (let elm of bg_polygon1) {
      observer.observe(elm)
   };
   for (let elm of bg_polygon2) {
      observer.observe(elm)
   };
   for (let elm of bg_gear1) {
      observer.observe(elm)
   };


$(document).ready(function(){
   $('.next_sect_link').mPageScroll2id({
      offset:120,
      scrollSpeed: 1000,
      scrollEasing: 'easeInOutQuint'
   });
   $('.next_section').mPageScroll2id({
      offset: 100,
      scrollSpeed: 1000,
      scrollEasing: 'easeInOutQuint'
   });
/**************************/
/*Slider*/
   $(document).ready(function() {
      $('.gallery_slider').slick({
          slidesToShow:1,
          slidesToScroll:1,
          dots: true,
          pauseOnFocus:false,
          pauseOnHover:false
      });
  });
/*Slider*/

new WOW().init();

});

let services_item_wrap1 = document.querySelector('.services_item_wrap1')
let services_item_wrap2 = document.querySelector('.services_item_wrap2')
let services_item_wrap3 = document.querySelector('.services_item_wrap3')
let services_item_wrap4 = document.querySelector('.services_item_wrap4')
let services_item_wrap5 = document.querySelector('.services_item_wrap5')
let services_item_wrap6 = document.querySelector('.services_item_wrap6')
let section4 = document.querySelector('.section4')
let sect1_left = document.querySelector('.sect1_left')
let sect2_text_bot = document.querySelector('.sect2_text_bot')
let sect2_text_top = document.querySelector('.sect2_text_top')

const mainElement = document.documentElement
const accessibleElementWidth = mainElement.clientWidth
const maxWidthNumber = 768

if(accessibleElementWidth <= maxWidthNumber) {
   section4.classList.remove('fadeIn')
   sect1_left.classList.remove('fadeInLeft')
   sect2_text_bot.classList.remove('fadeInLeft')
   sect2_text_top.classList.remove('fadeInRight')
   services_item_wrap1.classList.remove('fadeInRight')
   services_item_wrap2.classList.remove('fadeInRight')
   services_item_wrap3.classList.remove('fadeInRight')
   services_item_wrap4.classList.remove('fadeInRight')
   services_item_wrap5.classList.remove('fadeInRight')
   services_item_wrap6.classList.remove('fadeInRight')
}
else {
   section4.classList.add('fadeIn')
   sect1_left.classList.add('fadeInLeft')
   sect2_text_bot.classList.add('fadeInLeft')
   sect2_text_top.classList.add('fadeInRight')
   services_item_wrap1.classList.add('fadeInRight')
   services_item_wrap2.classList.add('fadeInRight')
   services_item_wrap3.classList.add('fadeInRight')
   services_item_wrap4.classList.add('fadeInRight')
   services_item_wrap5.classList.add('fadeInRight')
   services_item_wrap6.classList.add('fadeInRight')
}


/**************************/
/* Gallery *//* Gallery */ 
let popupBg = document.querySelector('.popup_bg');
let popup_bodyBlocked = document.querySelector('body')
/**************************/ 
/* Services Modal Window */
let serv_1 = document.querySelector('.serv_modal1')
let serv_2 = document.querySelector('.serv_modal2')
let serv_3 = document.querySelector('.serv_modal3')
let serv_4 = document.querySelector('.serv_modal4')
let serv_5 = document.querySelector('.serv_modal5')
let serv_6 = document.querySelector('.serv_modal6')

let serv_mod_slider = document.querySelector('.serv_modal_slider')

let serv_open_1 = document.querySelectorAll('.serv_1')
let serv_open_2 = document.querySelectorAll('.serv_2')
let serv_open_3 = document.querySelectorAll('.serv_3')
let serv_open_4 = document.querySelectorAll('.serv_4')
let serv_open_5 = document.querySelectorAll('.serv_5')
let serv_open_6 = document.querySelectorAll('.serv_6')

let serv_close1 = document.querySelectorAll('.serv_close1')
let serv_close2 = document.querySelectorAll('.serv_close2')
let serv_close3 = document.querySelectorAll('.serv_close3')
let serv_close4 = document.querySelectorAll('.serv_close4')
let serv_close5 = document.querySelectorAll('.serv_close5')
let serv_close6 = document.querySelectorAll('.serv_close6')

serv_open_1.forEach((button) => {
   button.addEventListener('click', (e) => {
       e.preventDefault();
       popupBg.classList.add('active');
       serv_1.classList.add('active_services');
       popup_bodyBlocked.classList.add ('active')
       serv_mod_slider.classList.add('active_services')
   })
});
serv_open_2.forEach((button) => {
   button.addEventListener('click', (e) => {
       e.preventDefault();
       popupBg.classList.add('active');
       serv_2.classList.add('active_services');
       popup_bodyBlocked.classList.add ('active')
       serv_mod_slider.classList.add('active_services')
   })
});
serv_open_3.forEach((button) => {
   button.addEventListener('click', (e) => {
       e.preventDefault();
       popupBg.classList.add('active');
       serv_3.classList.add('active_services');
       popup_bodyBlocked.classList.add ('active')
       serv_mod_slider.classList.add('active_services')
   })
});
serv_open_4.forEach((button) => {
   button.addEventListener('click', (e) => {
       e.preventDefault();
       popupBg.classList.add('active');
       serv_4.classList.add('active_services');
       popup_bodyBlocked.classList.add ('active')
       serv_mod_slider.classList.add('active_services')
   })
});
serv_open_5.forEach((button) => {
   button.addEventListener('click', (e) => {
       e.preventDefault();
       popupBg.classList.add('active');
       serv_5.classList.add('active_services');
       popup_bodyBlocked.classList.add ('active')
       serv_mod_slider.classList.add('active_services')
   })
});
serv_open_6.forEach((button) => {
   button.addEventListener('click', (e) => {
       e.preventDefault();
       popupBg.classList.add('active');
       serv_6.classList.add('active_services');
       popup_bodyBlocked.classList.add ('active')
       serv_mod_slider.classList.add('active_services')
   })
});

serv_close1.forEach((button) => {
   button.addEventListener('click', (e) => {
      e.preventDefault();
       serv_1.classList.remove('active_services');
       popupBg.classList.remove('active');
       popup_bodyBlocked.classList.remove ('active')
       serv_mod_slider.classList.remove('active_services')
   })
});
serv_close2.forEach((button) => {
   button.addEventListener('click', (e) => {
      e.preventDefault();
      serv_2.classList.remove('active_services');
       popupBg.classList.remove('active');
       popup_bodyBlocked.classList.remove ('active')
       serv_mod_slider.classList.remove('active_services')
   })
});
serv_close3.forEach((button) => {
   button.addEventListener('click', (e) => {
      e.preventDefault();
      serv_3.classList.remove('active_services');
       popupBg.classList.remove('active');
       popup_bodyBlocked.classList.remove ('active')
       serv_mod_slider.classList.remove('active_services')
   })
});
serv_close4.forEach((button) => {
   button.addEventListener('click', (e) => {
      e.preventDefault();
      serv_4.classList.remove('active_services');
       popupBg.classList.remove('active');
       popup_bodyBlocked.classList.remove ('active')
       serv_mod_slider.classList.remove('active_services')
   })
});
serv_close5.forEach((button) => {
   button.addEventListener('click', (e) => {
      e.preventDefault();
      serv_5.classList.remove('active_services');
       popupBg.classList.remove('active');
       popup_bodyBlocked.classList.remove ('active')
       serv_mod_slider.classList.remove('active_services')
   })
});
serv_close6.forEach((button) => {
   button.addEventListener('click', (e) => {
      e.preventDefault();
      serv_6.classList.remove('active_services');
       popupBg.classList.remove('active');
       popup_bodyBlocked.classList.remove ('active')
       serv_mod_slider.classList.remove('active_services')
   })
});

document.addEventListener('click', (e) => {
   if(e.target === popupBg) {
       popupBg.classList.remove('active');
       popup_bodyBlocked.classList.remove ('active')
       serv_mod_slider.classList.remove('active_services')

       serv_1.classList.remove('active_services');
       serv_2.classList.remove('active_services');
       serv_3.classList.remove('active_services');
       serv_4.classList.remove('active_services');
       serv_5.classList.remove('active_services');
       serv_6.classList.remove('active_services');
   }
});
/* Services Modal Window */
/**************************/
/* Burger */
let burger_header = document.querySelectorAll('.burger_header');
let close_burger_header = document.querySelectorAll('.close_burger_header');
let header_nav = document.querySelector('.header_nav');
let h1 = document.querySelector('.h1')
let h1_img = document.querySelector('.h1_img')
let close_burger_header2 = document.querySelector('.close_burger_header2')

let burger_line1 = document.querySelector('.burger_line1')
let burger_line2 = document.querySelector('.burger_line2')
let burger_line3 = document.querySelector('.burger_line3')

let close_burger_line1 = document.querySelector('.close_burger_line1')
let close_burger_line2 = document.querySelector('.close_burger_line2')
let next_sect_link = document.querySelectorAll('.next_sect_link')

let popup_bg2 = document.querySelector('.popup_bg2')


burger_header.forEach((button) => {
   button.addEventListener('click', (e) => {
       e.preventDefault();
       header_nav.classList.add('active')
       close_burger_line1.classList.add('active')
       close_burger_line2.classList.add('active')
       burger_line1.classList.add('opacity0')
       burger_line2.classList.add('opacity0')
       burger_line3.classList.add('opacity0')
       h1.classList.add('opacity0')
       h1_img.classList.add('opacity0')
       close_burger_header2.classList.add('active')
       popup_bodyBlocked.classList.add ('active')
       popup_bg2.classList.add('active')
   })
});

close_burger_header.forEach((button) => {
   button.addEventListener('click', (e) => {
       e.preventDefault();
       header_nav.classList.remove('active')
       close_burger_line1.classList.remove('active')
       close_burger_line2.classList.remove('active')
       burger_line1.classList.remove('opacity0')
       burger_line2.classList.remove('opacity0')
       burger_line3.classList.remove('opacity0')
       h1.classList.remove('opacity0')
       h1_img.classList.remove('opacity0')
       close_burger_header2.classList.remove('active')
       popup_bodyBlocked.classList.remove ('active')
       popup_bg2.classList.remove('active')
   })
});

document.addEventListener('click', (e) => {
   if(e.target === popup_bg2) {
      e.preventDefault();
      header_nav.classList.remove('active')
      close_burger_line1.classList.remove('active')
      close_burger_line2.classList.remove('active')
      burger_line1.classList.remove('opacity0')
      burger_line2.classList.remove('opacity0')
      burger_line3.classList.remove('opacity0')
      h1.classList.remove('opacity0')
      h1_img.classList.remove('opacity0')
      close_burger_header2.classList.remove('active')
      popup_bodyBlocked.classList.remove ('active')
      popup_bg2.classList.remove('active')
   }
});

next_sect_link.forEach((button) => {
   button.addEventListener('click', (e) => {
       e.preventDefault();
       header_nav.classList.remove('active')
       close_burger_line1.classList.remove('active')
       close_burger_line2.classList.remove('active')
       burger_line1.classList.remove('opacity0')
       burger_line2.classList.remove('opacity0')
       burger_line3.classList.remove('opacity0')
       h1.classList.remove('opacity0')
       h1_img.classList.remove('opacity0')
       close_burger_header2.classList.remove('active')
       popup_bodyBlocked.classList.remove ('active')
       popup_bg2.classList.remove('active')
   })
});
/* Burger */
/****************************/ 
/*Slider Gallery*/
let gallery_image1 = document.querySelectorAll('.gallery_image1')
let gallery_image2 = document.querySelectorAll('.gallery_image2')
let gallery_image3 = document.querySelectorAll('.gallery_image3')
let gallery_image4 = document.querySelectorAll('.gallery_image4')
let gallery_image5 = document.querySelectorAll('.gallery_image5')
// let gallery_image = document.querySelectorAll('.gallery_image')
// let gallery_image = document.querySelectorAll('.gallery_image')
// let gallery_image = document.querySelectorAll('.gallery_image')
/*Slider Gallery*/  

let gallery_slider_big_img1 = document.querySelector('.gallery_slider_big_img1')
let gallery_slider_big_img2 = document.querySelector('.gallery_slider_big_img2')
let gallery_slider_big_img3 = document.querySelector('.gallery_slider_big_img3')
let gallery_slider_big_img4 = document.querySelector('.gallery_slider_big_img4')
let gallery_slider_big_img5 = document.querySelector('.gallery_slider_big_img5')
// let gallery_slider_big_img1 = document.querySelector('.gallery_slider_big_img1')
// let gallery_slider_big_img1 = document.querySelector('.gallery_slider_big_img1')
// let gallery_slider_big_img1 = document.querySelector('.gallery_slider_big_img1')

let gal_img_close = document.querySelectorAll('.gal_img_close')


gallery_image1.forEach((button) => {
   button.addEventListener('click', (e) => {
      e.preventDefault()
      gallery_slider_big_img1.classList.add('active')
      popupBg.classList.add('active');
      popup_bodyBlocked.classList.add ('active')
   })
})
gallery_image2.forEach((button) => {
   button.addEventListener('click', (e) => {
      e.preventDefault()
      gallery_slider_big_img2.classList.add('active')
      popupBg.classList.add('active');
      popup_bodyBlocked.classList.add ('active')
   })
})
gallery_image3.forEach((button) => {
   button.addEventListener('click', (e) => {
      e.preventDefault()
      gallery_slider_big_img3.classList.add('active')
      popupBg.classList.add('active');
      popup_bodyBlocked.classList.add ('active')
   })
})
gallery_image4.forEach((button) => {
   button.addEventListener('click', (e) => {
      e.preventDefault()
      gallery_slider_big_img4.classList.add('active')
      popupBg.classList.add('active');
      popup_bodyBlocked.classList.add ('active')
   })
})
gallery_image5.forEach((button) => {
   button.addEventListener('click', (e) => {
      e.preventDefault()
      gallery_slider_big_img5.classList.add('active')
      popupBg.classList.add('active');
      popup_bodyBlocked.classList.add ('active')
   })
})

gal_img_close.forEach((button) => {
   button.addEventListener('click', (e) => {
      e.preventDefault()
      gallery_slider_big_img1.classList.remove('active')
      gallery_slider_big_img2.classList.remove('active')
      gallery_slider_big_img3.classList.remove('active')
      gallery_slider_big_img4.classList.remove('active')
      gallery_slider_big_img5.classList.remove('active')

      popupBg.classList.remove('active');
      popup_bodyBlocked.classList.remove ('active')
   })
})
document.addEventListener('click', (e) => {
   if(e.target === popupBg) {
      gallery_slider_big_img1.classList.remove('active')
      gallery_slider_big_img2.classList.remove('active')
      gallery_slider_big_img3.classList.remove('active')
      gallery_slider_big_img4.classList.remove('active')
      gallery_slider_big_img5.classList.remove('active')

      popupBg.classList.remove('active');
      popup_bodyBlocked.classList.remove ('active')
   }
});