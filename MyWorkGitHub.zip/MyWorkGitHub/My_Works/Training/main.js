// const stringNumb = '40'
// const stringNumbDecimal = '40.42'

// console.log(Number.parseInt(stringNumb) + 2)
// console.log(Number(stringNumb) + 2)
// console.log(+stringNumb + 2)

// console.log(parseFloat(stringNumbDecimal) + 2)


// console.log(0.4 + 0.2)
// console.log(+(0.4 + 0.2).toFixed(1))
// console.log(parseFloat((0.4 + 0.2).toFixed(1)))

// Math

// console.log(Math.E)
// console.log(Math.PI)
// console.log(Math.pow(x = 25, y = 2))
// console.log(Math.abs(-422))
// console.log(Math.max(25, 400, 33))
// console.log(Math.min(25, 422, 33))
// console.log(Math.floor(11.99))
// console.log(Math.ceil(11.01))
// console.log(Math.round(4.5))
// console.log(Math.round(4.4))
// console.log(Math.trunc(11.01))
// console.log(Math.random())

// function minMaxValue (min, max) {
//    return Math.floor(Math.random() * (max - min) + min)  
// }
// console.log(minMaxValue(0, 100))


// const myAge = 21
// const myName = 'Андрей'

// const output = `Моё имя ${myName}, и мне ${myAge} год`
// console.log(output)


// const myAge = 21
// const myName = 'Андрей'
// const space = '   space   '

// console.log(myName.length)
// console.log(myName.toUpperCase())
// console.log(myName.toLowerCase())
// console.log(myName.toLowerCase().startsWith('ан'))
// console.log(myName.charAt(5))
// console.log(myName.indexOf('е'))
// console.log(myName.indexOf('з'))
// console.log(myName.startsWith('ан'))
// console.log(myName.startsWith('Ан'))
// console.log(myName.endsWith('й'))
// console.log(myName.endsWith('й!'))
// console.log(myName.repeat(3))
// console.log(space)
// console.log(space.trim())
// console.log(space.trimLeft())
// console.log(space.trimRight())
// console.log(space.trimStart())


// function logPerson(s, name, age) {
//    // return `${s[0]}${name}${s[1]}${age}${s[2]}`
//    if(age < 0){
//       age = 'Не родился'
//    }
//    console.log(s, name, age)
// }


// const personName = 'Андрей'
// const personName2 = 'Влад'
// const personAge = '21'
// const personAge2 = '-1'

// const output = logPerson`Меня зовут ${personName}, мой возраст ${personAge}`
// const output2 = logPerson`Меня зовут ${personName2}, мой возраст ${personAge2}`

// console.log(output)
// console.log(output2)

// const arrow = age => console.log('', age)

// arrow ('21')

// const textArray = 'Привет, мы изучаем JavaScript'

// const workArray = textArray.split('').join('')

// console.log(workArray)

// const cars = ['Mazda', 'Mersedes', 'Audi', 'BMW', 'Volvo']

// const index = cars.indexOf('BMW')
// cars[index] = 'Porshe'
// console.log(cars)

// const people = [
//    {name: 'Andrew', money: 4000},
//    {name: 'Skotch', money: 5400},
//    {name: 'Suvanda', money: 3400}
// ]

// const index = people.findIndex(function(person) {
//    // console.log(person)
//    return person.name === 'Andrew'
// })

// const person = people.find(function(person) {
//    // console.log(person)
//    return person.name === 'Andrew'
// })
// console.log(person)

// console.log(index)
// console.log(people[index])

// const person1 = people.find(person => person.name === 'Andrew')
// console.log(person1)

// const person2 = people.find(person => person.money === 3400)
// console.log(person2)

// const cars = ['Mazda', 'Mersedes', 'Audi', 'BMW', 'Volvo']

// const upperCaseCars = cars.map(bigCar => {
//    return bigCar.toUpperCase()
// })
// const lowerCaseCars = cars.map(smallCar => {
//    return smallCar.toLowerCase()
// })

// console.log(cars)
// console.log(upperCaseCars)
// console.log(lowerCaseCars)

// const numbers = [1, 3, 6, 10, 15]

// const pow2 = num => num ** 2
// const sqrt = num => Math.sqrt(num)

// const pow2Fib = numbers.map(pow2)
// console.log(pow2Fib)


// const numbers = [1, 3, 6, 10, 15]

// const pow2Fib = numbers.map(pow2)
// const filteredNumbers = pow2Fib.filter(num => num > 20)
// console.log(filteredNumbers)
// console.log(pow2Fib)


// const people = [
//    {name: 'Andrew', money: 4000},
//    {name: 'Skotch', money: 5400},
//    {name: 'Suvanda', money: 3400}
// ]

// const allSum = people.filter(person => person.money > 3500).reduce((sum, person) => {
//    sum += person.money
//    return sum
// }, 0)
// console.log(allSum)



// const myPerson = {
//    name: 'Andrew',
//    age: 21,
//    placeOfResidence: 'Dnipro',
//    education: 'Fiz teraphist',
//    car: undefined,
//    languages: ['ukr', 'ru', 'pl', 'eng'],
//    greet() {
//       console.log('Its me!')
//    }
// }

// myPerson.languages.push('fr')
// delete myPerson.age
// const {name, age, languages} = myPerson
// console.log(name, age, languages)


// for(let key in myPerson) {
//    if(myPerson.hasOwnProperty(key)) {
//       console.log('key: ', key)
//       console.log('value: ', myPerson[key])
//    }
// }

// Object.keys(myPerson).forEach((key) => {
//    console.log('key: ', key)
//    console.log('value: ', myPerson[key])
// })