'use strict'


// let messege = 'Hello'
// let messege2 = 'World'
// messege = messege2
// const define = messege = messege2
// console.log('Variant-1: ', messege)
// console.log('Variant-2: ', define)

// console.log('.' / 2) // typeOf - Infinity
// console.log(NaN / 2) // typeOf - Nan
// console.log(NaN ** 0) // result = 1 // typeOf - number

// console.log(2 ** 53 -1)
// let number = 9007199254740991
// console.log(Number.MAX_SAFE_INTEGER)// Max value = '+' 9007199254740991
// console.log(Number.MIN_SAFE_INTEGER)// Min value '-' 9007199254740991

// console.log(90071992547409911111n) //- BigInt - value is more than 

// const myName = 'Andrew'
// const myAge = 10.5 * 2
// const myEducation = 'fiziotheraphist'

// const compound = `My name is ${myName}, and im ${myAge} years. My education is ${myEducation} theraphist.`

// console.log(compound)


// const isGreater = 4 > 1
// console.log(isGreater)

// typeOf 
// console.log(typeof'')// retrun - string
// console.log(typeof 25)// retur - number
// console.log(typeof undefined) // return - undefined
// console.log(typeof null) // return - Object
// console.log(typeof true) // return - boolean
// console.log(typeof 10n) // return - bigInt


// const name = 'Ilya'
// console.log(`hello ${1}`)// hello 1
// console.log(`hello ${'name'}`)// hello name
// console.log(`hello ${name}`)// hello Ilya


// let title = 'Введите пароль'
// console.log(prompt(title))


// let age = prompt('Сколько тебе лет?');

// console.log(`Тебе ${age} лет!`); // Тебе 100 лет!
// alert(`Тебе ${age} лет!`); // Тебе 100 лет!


// let value1 = true// Boolean
// let value0 = false// Boolean
// let stringInNumber = '12345'
// let stringInNumberNan = '12345n'

// console.log(value)// result - Boolean
// value = String(value)// String
// console.log(value)// result - String

// value1 = Number(value1)
// value0 = Number(value0)
// console.log(value1)
// console.log(value0)

// stringInNumber = Number(stringInNumber)
// stringInNumberNan = Number(stringInNumberNan)
// console.log(stringInNumber)
// console.log(stringInNumberNan)

// let a1 = 1
// let a2 = 1
// let c1 = ++a1;
// let c2 = a2++;
// console.log(c1) //2
// console.log(c2) //1


// console.log('"" + 1 + 0', '' + 1 + 0)// 10
// console.log('"" - 1 + 0', "" - 1 + 0)// -1

// console.log('Boolean("")', Boolean(''))
// console.log('Boolean(" ")', Boolean(' '))

// console.log('0 == false', 0 == false)
// console.log('0 === false', 0 === false)

// console.log('null == undefined', null == undefined)
// console.log('null == undefined', null === undefined)

// console.log('null == 0', null == 0)
// console.log('null >= 0', null >= 0)

// 
// const textToUpperCase = 'indefined does not compare'
// console.log(textToUpperCase.toUpperCase())
// 


// INDEFINED DOES NOT COMPARE( Undefined Не сравнимо с чем-либо )

// console.log( undefined > 0 ); // false (1)
// console.log( undefined < 0 ); // false (2)
// console.log( undefined == 0 ); // false (3)



// let year = prompt('В каком году была опубликована спецификация ECMAScript-2015?', '');

// if(year == 2015) {
//    console.log('true')
// }
// else {
//    console.log('false')
// }

// let year = prompt('В каком году была опубликована спецификация ECMAScript-2015?', '');

// if (year < 2015) {
//   console.log( 'Это слишком рано...' );
// } else if (year > 2015) {
//   console.log( 'Это поздновато' );
// } else {
//   console.log( 'Верно!' );
// }


// let year = prompt('В каком году была опубликована спецификация ECMAScript-2015?', '');

// let yearDefine = (year < 2015) ? 'Маловато' : (year > 2015) ? 'Слишком много' : 'Верно';
// console.log(yearDefine)


// let age = prompt('Возраст?', 18);

// let message = (age < 3) ? 'Здравствуй, малыш!' : (age < 18) ? 'Привет!' : (age < 100) ? 'Здравствуйте!' :
//   'Какой необычный возраст!';

// alert( message );

// БОЛЕЕ КОРОТКАЯ И ЛУЧШАЯ ЗАПИСЬ УСЛОВИЯ КОТОРОЕ ПРИВЕДЕНО ВЫШЕ
// let result = условие ? значение1 : значение2;

// let accessAllowed;
// let age = prompt('Сколько вам лет?', '');

// let accessAllowed = age >= 18 ? true : false;
// let accessAllowed = age >= 18 // ЕЩЁ ЛУЧШАЯ ЗАПИСЬ

// console.log(accessAllowed)


// const nameJS = prompt('„Какое «официальное» название JavaScript?“', '')

// let askMe = (nameJS == 'ECMAScript') ? 'Верно!' : ' Не знаете? ECMAScript!'
// console.log(askMe)


// let value = prompt('')

// let defineValue = (value > 0) ? alert(1) : (value < 0) ? alert(-1) : alert(0)


// let value = prompt('')

// if(value > 0) {
//    alert(1)
// }
// if(value < 0) {
//    alert(-1)
// }
// else {
//    alert(0)
// }


// let login = prompt('');

// if (login == 'Сотрудник') {
//   console.log('Привет')
// } else if (login == 'Директор') {
//    console.log('Здравствуйте')
// } else if (login == '') {
//   console.log('Нет логина')
// } else {
//   console.log('Не верно')
// }


// let login = prompt('');

// const defineWorker = (login == 'Сотрудник') ? console.log('Привет') : 
// (login == 'Директор') ? console.log('Здравствуйте'): 
// (login == '') ? console.log('Нет логина') : console.log('Не верно')


// const age = 33
// if(age <= 14 && age <= 90){}// Age В диапазоне
// // if(age < 14 || age < 90){}// Age Вне диапазона
// if(!(age <= 14 && age <= 90)){}// Age Вне диапазона


// const admin = prompt('Admin', '')
// if(admin == 'Admin'){
//    const password = prompt('Введите пароль', '')
//    if(password == 'Я главный'){
//       console.log('Здравствуйте')
//    }
//    else if(password == null){
//       console.log('Отменено')
//    }
//    else {
//       console.log('Неверный пароль')
//    }
// }
// else if(admin == '' || admin == null){
//    console.log('Отменено')
// }
// else {
//    console.log('Неверный пароль')
// }


// Оператор Нулевого Слияния "??"
// работает с null и undefined

// let height = null;
// let width = null;

// // важно: используйте круглые скобки
// let area = (height ?? 100) * (width ?? 50);

// console.log(area); // 5000
////
// let myName = undefined
// let myAge = undefined

// let persone = (myName ?? 'Andrew') + (myAge ?? 21)
// console.log(persone)


// Цикл while 
// do {
//    // тело цикла
//  } while (условие);


// Цикл For
// for(let myAge = 21; myAge <= 30; myAge++){
//    console.log(myAge)
// }
// В примере переменная счётчика "myAge" была объявлена прямо в цикле. Это так называемое «встроенное» объявление переменной. Такие переменные существуют только внутри цикла.

// Но можно так:
// let myAge = 21
// for(myAge = 21; myAge <= 30; myAge++){
//    console.log(myAge)
// }


// let sum = 0;

// while (true) {

//   let value = +prompt("Введите число", '');

//   if (!value) break; // (*)

//   sum += value;

// }
// alert( 'Сумма: ' + sum );


// for (let i = 0; i < 10; i++) {

//    // если true, пропустить оставшуюся часть тела цикла
//    if (i % 2 == 0) continue;
 
//    console.log(i); // 1, затем 3, 5, 7, 9
//  }



// for(let a = 2; a <= 10; a++){
//    if(a % 2 == 0){
//       console.log(a)
//    }
// }

// Цикл "for" выше равен циклу "while" ниже, они выполняют одно и тоже.

// for (let i = 0; i < 3; i++) {
//    alert( `number ${i}!` );
// }


// let i = 0

// while(i < 3){
//    alert(`number ${i}!`)
//    i++
// }

// 
// Switch
// 

// switch (browser) {
//    case 'Edge':
//      alert( "You've got the Edge!" );
//      break;
 
//    case 'Chrome':
//    case 'Firefox':
//    case 'Safari':
//    case 'Opera':
//      alert( 'Okay we support these browsers too' );
//      break;
 
//    default:
//      alert( 'We hope that this page looks ok!' );
// }


// Это 
// let browser = prompt('')

// switch (browser) {
//    case 'Edge':
//      alert( "You've got the Edge!" );
//      break;
 
//    case 'Chrome':
//    case 'Firefox':
//    case 'Safari':
//    case 'Opera':
//      alert( 'Okay we support these browsers too' );
//      break;
 
//    default:
//      alert( 'We hope that this page looks ok!' );
// }

// Тоже самое что это

// let messege = prompt('')

// if(messege == 'Edge'){
//    alert( "You've got the Edge!" );
// }
// else if (messege == 'Chrome' || messege == 'Firefox' || messege == 'Safari' || messege == 'Opera'){
//    alert( 'Okay we support these browsers too' );
// }
// else{
//    alert( 'Это бред' );
// }

// 


// const number = +prompt('Введите число между 0 и 3', '');

// if (number === 0) {
//   alert('Вы ввели число 0');
// }

// if (number === 1) {
//   alert('Вы ввели число 1');
// }

// if (number === 2 || number === 3) {
//   alert('Вы ввели число 2, а может и 3');
// }

// Код выше тоже самое что код внизу

// const number = +prompt('Введите число между 0 и 3', '');

// switch(number){
//    case 0:
//       alert('Вы ввели число 0');
//       break;
//    case 1:
//       alert('Вы ввели число 1');
//       break;
//    case 2:
//    case 3:
//       alert('Вы ввели число 2, а может и 3');
//       break;
// }

// 
// Function
// 

// const sum = (a, b) => {
//    return a + b;
// }

// console.log(sum(10, 2))


// function checkAge(age) {
//    if (age > 18) {
//      return true;
//    } else {
//      return confirm('Родители разрешили?');
//    }
// }

// let checkAge = (age) => {
//    return (age > 18) ? true : confirm('Родители разрешили ?');
// }

// function checkAge(age) {
//    return (age > 18) ? true : confirm('Родители разрешили ?');
// }

// function checkAge(age) {
//    age = 20
//    return age > 18 || confirm('Родители разрешили ?');
// }
// checkAge()



// function ask(question, yes, no) {
//    if (confirm(question)) yes()
//    else no();
//    }
   
//    function showOk() {
//    alert( "Вы согласны." );
//    }
   
//    function showCancel() {
//    alert( "Вы отменили выполнение." );
//    }
   
//    // использование: функции showOk, showCancel передаются в качестве аргументов ask
//    ask("Вы согласны?", showOk, showCancel);


// function ask(question) {
//    if (confirm(question)) {
//    alert( "Вы согласны." );
// }
//    else {
//    alert( "Вы отменили выполнение." );
// }
// }
// ask("Вы согласны?");


// let age = prompt("Сколько Вам лет?", '');

// // в зависимости от условия объявляем функцию
// if (age < 18) {

//   function welcome() {
//     alert("Привет!");
//   }
//   welcome();
// } else {

//   function welcome() {
//     alert("Здравствуйте!");
//   }
//   welcome();
// }

// 
// Это Function Declaration

// let age = prompt("Сколько Вам лет?", 18);
// let welcome;

// if (age < 18) {
//    welcome = function() {
//       alert("Привет!");
//    };
// } 
// else {
//    welcome = function() {
//       alert("Здравствуйте!");
//    };
// }

// welcome();

// 
// Это Function Expression

// let age = prompt("Сколько Вам лет?", 18);
// let welcome = (age < 18) ? 
// function() {alert("Привет!")} : 
// function() {alert("Здравствуйте!")}

// welcome()


// let age = prompt("Сколько Вам лет?", 18);

// let welcome = (age < 18) ? 
// () => alert('Привет!') : 
// () => alert("Здравствуйте!");

// welcome()


// function ask(question, yes, no) {
//    if (confirm(question)) yes()
//    else no();
//  }
 
//  ask(
//    "Вы согласны?",
//    function() { alert("Вы согласились."); },
//    function() { alert("Вы отменили выполнение."); }
//  );


// function ask(question, yes, no) {
//    confirm(question) ? yes() : no();
// }
// ask(
//    "Вы согласны?",
//    () => { alert("Вы согласились."); },
//    () => { alert("Вы отменили выполнение."); }
// );

// 
// Объекты: основы
// 

// let user = {
//    name: "John",
//    age: 30
//  };
 
//  let key = prompt("Что вы хотите узнать о пользователе?", 'age');
 
//  // доступ к свойству через переменную
//  alert( user[key] ); // John (если ввели "name")


// let fruit = prompt("Какой фрукт купить?", "apple");

// let bag = {
//   [fruit]: 5, // имя свойства будет взято из переменной fruit
// };

// alert( bag.apple ); // 5, если fruit="apple"

// 
// Проверка на существования свойства
// 

// let user = { age: 30 };

// let key = "age";
// alert( key in user ); // true, имя свойства было взято из переменной key


// let obj = {
//    test: undefined
//  };
 
//  alert( obj.test ); //  выведет undefined, значит свойство не существует?
//  alert( "test" in obj ); // true, свойство существует!

// 
// Цикл for in
// 

// let user = {
//    name: "John",
//    age: 30,
//    isAdmin: true
// };
// for(let key in user){
//    console.log(user[key])
// }

// 
// Method "Math.trunc"
// 

// console.log( String(Math.trunc(Number("1.2"))) );// = 1

// 
// Клонирование объектов(создается новая ("myPersonClone") копия старого объекта ("myPerson"), то есть новый объект но копия старого)
//

// let myPerson = {
//    name: 'Andrew',
//    age: 21,
//    citizenship: 'Ukrainian'
// };
 
// let myPersonClone = {}
 
// for (let key in myPerson) {
//    myPersonClone[key] = myPerson[key];
// }

// 
// Object.assign выполняет тоже самое что цикл "for in" для копирования другого объекта. То есть для клонирования объекта можно использовать Object.assign
//

// let permissions1 = { languages: ['eng', 'ukr', 'pl', 'rus'] };
// let permissions2 = { car: false };

// Object.(myPerson, permissions1, permissions2);
// console.log(myPerson)

// let user = {
//    name: "Иван",
//    sizes: {
//      height: 182,
//      width: 50
//    }
// };

// let clone = JSON.parse(JSON.stringify(user));
// let clone2 = JSON.parse(JSON.stringify(user))
 
// console.log( user.sizes === clone.sizes ); // true, один и тот же объект
 
// // user, clone и clone2 обращаются к одному sizes
// clone.sizes.width++;       // меняем свойство
// clone2.sizes.width = 55;       // меняем свойство
// console.log(clone.sizes.width); // width = 51
// console.log(clone2.sizes.width); // width = 55
// console.log(user.sizes.width) // width = 50
// То есть старый и новый объекты ссылаются на вложеный в них объект "sizes". Это значит что при поверхностном копировании объекта, вложенные объекты не копируются. А это значит что старый родительский объект и его копия просто ссылаются на уже существующий уникальный вложеный объект в родительском объекте (объект "sizes" вложен в объект "user") изменения в "user.sizes" или "clone.sizes". Для того чтобы объект "sizes" так же имел свой вложеный объект "sizes" нужно делать глубокое копирование.


// 
// Для глубоко копирования можно использовать методы JSON.parse(JSON.stringify(original object))
// 


// let user = {
//    name: "Иван",
//    sizes: {
//      height: 182,
//      width: 50
//    }
// };

// let clone = JSON.parse(JSON.stringify(user));
// let clone2 = JSON.parse(JSON.stringify(user))
 
// console.log( user.sizes === clone.sizes ); // true, один и тот же объект
 

// clone.sizes.width++;
// clone2.sizes.width = 55;    
// console.log(clone.sizes.width);// width = 51 
// console.log(clone2.sizes.width);// width = 55
// console.log(user.sizes.width);

// 
// Цикл "for in"
// 

// function sumTo(n){
//    let sum = 0;  
//    for(let i = 1; i <= n; i++){
//       sum += i
//    } 
//    return sum 
// }
// console.log(sumTo(100))


// function sumTo(n){
//    let result = 0
//    for(let i = 1; i <= n; i++){
//       result += i
//    }
//    return result
// }
// console.log(sumTo(100000))

// Тожк самое что и цикл, только рекурсия 

// function pow(n){
//    if(n == 1) return 1;
//    return n + pow(n - 1);
// }
// console.log(pow(4))

// 
// Счётчик 
// 

// let currentCount = 1;
// function makeCounter(){
//    return function(){
//       return currentCount++;
//    }; 
// }
// let counter = makeCounter();
// let counter2 = makeCounter();

// console.log(counter());
// console.log(counter2());


// function sum(a, b){
//    return a + b
// }
// console.log(sum(1, 2))


// Пример с function sum(a)(b){}, чтобы возвращался результат a + b

// function sum(a){
//    return function(b){
//       return a + b
//    }
// }
// console.log(sum(1)(2))


// Функция – строковый буфер
// function makeBuffer(){
//    let text = '';
   
//    return function(piece){
//       if(arguments.length == 0){
//          return text;
//       };
//       text += piece
//    };
// };

// let buffer = makeBuffer();

// buffer('"Замыкания"');
// buffer(' ');
// buffer('Использовать');
// buffer(' ');
// buffer('Нужно !!!');
// console.log(buffer())


// Функция – строковый буфер
// function makeBuffer(){
//    let text = '';
   
//    function buffer(piece){
//       if(arguments.length == 0){
//          return text;
//       };
//       text += piece
//    };
//    buffer.clear = function(){
//       text = ''
//    }
//    return buffer
// };

// let buffer = makeBuffer();

// buffer("Тест");
// buffer(' ');
// buffer("тебя не съест ");
// console.log(buffer());
// buffer.clear();
// console.log(buffer());



// let user = {name: 'Василий' };
// user.sayHi = function(){
//    alert('Привет!');
// };
// user.sayHi();


// delete user?.name; // удаляет user.name если пользователь существует

// let id = Symbol("id");
// alert(id.description); //"Object.description" выводит описание. Хорошо работает если, например, в "alert" нужно вывести содержимое с типом данных "Symbol". Этот тип данных при выводе в "alert", который преобразовывает в тип данных "String" вызовет ошибку, ведь "Symbol" не преобразуется в "String". 

// Object.assign, в отличие от цикла for..in, копирует и строковые, и символьные свойства

// Технически символы скрыты не на 100%. Существует встроенный метод Object.getOwnPropertySymbols(obj) – с его помощью можно получить все свойства объекта с ключами-символами. Также существует метод Reflect.ownKeys(obj), который возвращает все ключи объекта, включая символьные. 



// let str = "Привет";

// str.test = 5;
// console.log(str.test);
// Примитивы не объекты, поэтому они не могут хранить дополнительные данные. Поэтому этот код выведет ошибку.


// Можно использовать унарный оператор +, чтобы преобразовать строку в число:
// let sum = 0.1 + 0.2;
// alert( +sum.toFixed(2) ); // 0.3


// let sum1 = prompt('')
// let sum2 = prompt('')
// alert(+(sum1 + sum2))



// function readNumber(){
//    let num
//    do{
//       num = prompt('Введите число: ', 0)
//    }
//    while(!isFinite(num))

//    if(num === null || num === '') return null;
//    return +num;
// }

// alert(`'Число: ' ${readNumber()}`)


// let str = 'Hi';
// str = 'h' + str[1]; // заменяем строку
// alert( str ); // hi


// Чтобы найти все вхождения подстроки, нужно запустить indexOf в цикле. Каждый раз, получив очередную позицию, начинаем новый поиск со следующей:

// let str = 'Ослик Иа-Иа посмотрел на виадук';
// let target = 'Иа'; // цель поиска

// let pos = 0;
// while (true) {
//   let foundPos = str.indexOf(target, pos);
//   if (foundPos == -1) break;

//   alert( `Найдено тут: ${foundPos}` );
//   pos = foundPos + 1; // продолжаем со следующей позиции
// }

// str.indexOf(target, pos);// ищет с начала строки до первого совпадения
// str.lastIndexOf(target, position);// ищет с конца строки до первого совпадения


// При проверке indexOf в условии if есть небольшое неудобство. Такое условие не будет работать:

// let str = "Widget with id";

// if (str.indexOf("Widget")) {
//     alert("Совпадение есть"); // не работает
// }
// Мы ищем подстроку "Widget", и она здесь есть, прямо на позиции 0. Но alert не показывается, т. к. str.indexOf("Widget") возвращает 0, и if решает, что тест не пройден.
// Поэтому надо делать проверку на -1:


// Вот так будет работать с "!= -1"
// let str = "Widget with id";

// if (str.indexOf("Widget") != -1) {
//     alert("Совпадение есть"); // теперь работает
// }


// Заменить "!= -1" можно с помощью знака "Не" "~". В нашем примере это выглядело бы так "~str.indexOf("Widget") - означает - если совпадение найдено" : 
// let str = "Widget";

// if (~str.indexOf("Widget")) {
//   alert( 'Совпадение есть' ); // работает
// }


// Лучше использовать "includes"
// alert( "Widget with id".includes("Widget") ); // true
// alert( "Hello".includes("Bye") ); // false


// Методы str.startsWith и str.endsWith проверяют, соответственно, начинается ли и заканчивается ли строка определённой строкой:
// alert( "Widget".startsWith("Wid") ); // true, "Wid" — начало "Widget"
// alert( "Widget".endsWith("get") ); // true, "get" — окончание "Widget"


// Slice - Возвращает часть строки от start до (не включая) end.

// let str = "stringify";
// // 'strin', символы от 0 до 5 (не включая 5)
// alert( str.slice(0, 5) );
// // 's', от 0 до 1, не включая 1, т. е. только один символ на позиции 0
// alert( str.slice(0, 1) );

// Лучше всех метод Slice, он короче всех и более гибкий.
// 
// 


// let str = '';

// for (let i = 65; i <= 220; i++) {
//   str += String.fromCodePoint(i);
// }
// alert( str );
// // ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~
// // ¡¢£¤¥¦§¨©ª«¬­®¯°±²³´µ¶·¸¹º»¼½¾¿ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖ×ØÙÚÛÜ


// ucFirst("вася") == "Вася";
// let str = 'Hi';
// str = 'h' + str[1]; // заменяем строку
// alert( str ); // hi


// Мы можем явно вычислить индекс последнего элемента, а затем получить к нему доступ вот так: 
// fruits[fruits.length - 1].

// let fruits = ["Apple", "Orange", "Plum"];
// // console.log(fruits.length)
// // alert( fruits[fruits.length - 1]);// Plum
// console.log(fruits.find(0))


// let arr = ["Яблоко", "Апельсин", "Груша"];

// console.log(arr[0])
// for (let i = 0; i < arr.length; i++) {
//   console.log( arr[i] );
// }


