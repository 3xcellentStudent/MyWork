'use strict'


// const cars = [
//    {name: 'Porsche 911', price: '200 000$'},
//    {name: 'Porsche 911S', price: '240 000$'},
//    {name: 'Audi Q7', price: '55 000$'},
//    {name: 'Audi Q8', price: '68 000$'},
//    {name: 'Audi S4', price: '45 000$'},
//    {name: 'BMW M3', price: '40 000$'},
//    {name: 'BMW M5', price: '100 000$'},
//    {name: 'Maserati', price: '45 000$'},
//    {name: 'Ferrari 599 GTB', price: '300 000$'},
//    {name: 'Ferrari Enzo', price: '500 000$'},
//    {name: 'Mercedes CLK GTR', price: '370 000$'},
//    {name: 'Mercedes R230', price: '200 000$'},
//    {name: 'Aston Martin DB9', price: '150 000$'},
//    {name: 'Bentley Continental GT', price: '260 000$'},
//    {name: 'Rolls-Royce', price: '600 000$'},
//    {name: 'Volkswagen Amarok', price: '25 000$'},
//    {name: 'Volkswagen Golf GT', price: '40 000$'},
//    {name: 'Volkswagen Tiguan', price: '20 000$'},
//    {name: 'Volvo', price: '29 000$'},
//    {name: 'Bugatti Chiron', price: '1 000 000$'},
//    {name: 'Aston Martin DBR9', price: '400 000$'},
// ]

// // 
// // 
// // 
// // 
// // 


/******/
// Регулярные выражения и метод "push()" у массивов
/******/


// const carsPrice = cars.map(car => Number(car.price.replace(/[\$\s]/g, '')))
// // // /[\$\s]/g // --- Регулярное выражение.

// const expCars = []

// // Expensive Cars
// for(expPrice of carsPrice){
//    if(expPrice <= 100000){
//       expCars.push(expPrice)
//    }
// }

// console.log(expCars)

// const cheapCars = []

// for(expPrice of carsPrice){
//    if(expPrice >= 100000){
//       cheapCars.push(expPrice)
//    }
// }
// console.log(cheapCars)


/******/
// Метод "concat()" у массивов
/******/


const arrayPorsche = [
   {name: 'Porsche 911', price: '200 000$'},
   {name: 'Porsche 911S', price: '240 000$'},
   {name: 'Porsche Taycan', price: '153 000$'}
]
const arrayAudi = [
   {name: 'Audi Q7', price: '55 000$'},
   {name: 'Audi Q8', price: '68 000$'},
   {name: 'Audi S4', price: '45 000$'},
]
const arrayBMW = [
   {name: 'BMW M3', price: '40 000$'},
   {name: 'BMW M5', price: '100 000$'},
]
const arrayFerrari = [
   {name: 'Ferrari 599 GTB', price: '300 000$'},
   {name: 'Ferrari Enzo', price: '500 000$'},
]
const arrayMerc= [
   {name: 'Mercedes CLK GTR', price: '370 000$'},
   {name: 'Mercedes R230', price: '200 000$'},
]
const arrayVolks = [
   {name: 'Volkswagen Amarok', price: '25 000$'},
   {name: 'Volkswagen Golf GT', price: '40 000$'},
   {name: 'Volkswagen Tiguan', price: '20 000$'},
]

// const Merc_BMW = arrayMerc.concat(arrayBMW)
// console.log(Merc_BMW)

// const Porsche_Audi_Volks = arrayAudi.concat(arrayPorsche, arrayVolks)
// console.log(Porsche_Audi_Volks)


// Копирует другие объекты, даже если они выглядят как массивы, добавляются как есть:
// let arr = [1, 2];
// let arrayLike = {
//   0: "что-то",
//   length: 1
// };
// console.log( arr.concat(arrayLike) ); // 1,2,[object Object]

// const arrayAudi2 = [
//    {name: 'Audi Q7', price: '55 000$'},
//    {name: 'Audi Q8', price: '68 000$'},
//    {name: 'Audi S4', price: '45 000$'},
//    {sportСar: [
//       {name: 'Audi R8', price: '80 000$'},
//       {name: 'Audi RS6', price: '121 000$'},
//    ]},
// ]

// const newArrayAudi = arrayAudi2.concat(arrayMerc)
// Скопировали два массива с вложенным масивом в новый массив.


/******/
// Метод "splice()"
/******/


// arrayPorsche.splice(2, 1)
// console.log(arrayPorsche)
// Удаление одного элемента начиная с позиции 2. То есть удалятся первые 2 элемента. Первое значение это с какого индекса начинается операция. Второе число означает количество элементов которые нужно удалить из массива.

// Удаление и добавление элементов с помощью "splice()"

// arrayPorsche.splice(0, 3, arrayPorsche[0], arrayPorsche[2])
// console.log(arrayPorsche)
// Сначала удалили первые три элемента массива, а потом добавили новые элементы.


// "splice()" возвращает массив из удаленных элементов. Для этого его нужно объявить в переменной.
// const removedArray = arrayPorsche.splice(0, 2)
// console.log(removedArray)


/******/
// Метод "slice()" возвращает новый массив в из скопированных элементов.
/******/ 


// const newArrayPorsche = arrayPorsche.slice(0, 3)
// console.log(newArrayPorsche)


/******/ 
// Метод "ForEach" позволяет запускать функцию для каждого/всех элементов массива.
/******/ 

// arrayPorsche.forEach(function(item){
//    console.log(item)
// })





// let company = { // тот же самый объект, сжатый для краткости
//    sales: [
//       {name: 'John', salary: 1000},
//       {name: 'Alice', salary: 600 }
//    ],
//    development: {
//       sites: [
//          {name: 'Peter', salary: 2000},
//          {name: 'Alex', salary: 1800 }
//       ],
//       internals: [
//          {name: 'Jack', salary: 1300}
//       ]
//    }
// };
 
 // Функция для подсчёта суммы зарплат
// function sumSalaries(salary) {
//    if (Array.isArray(salary)) { // случай (1)
//       return salary.reduce((prev, current) => prev + current.salary, 0); // сумма элементов массива
//    } 
//    else { // случай (2)
//       let sum = 0;
//       for (let subdep of Object.values(salary)) {
//          sum += sumSalaries(subdep); // рекурсивно вызывается для подотделов, суммируя результаты
//       }
//       return sum;
//    }
// }
 
// console.log(sumSalaries(company)); // 6700



// Вычислить сумму чисел до данного c использованием цикла и через рекурсию

// function sumTo(n){
//    let sum = 0
//    for(let i = 1; i <= n; i++){
//       sum += i
//    }
//    return sum
// }
// console.log(sumTo(4))


// function sumTo(n){
//    if(n == 1) return 1;
//    else{
//       return n + sumTo(n - 1);
//    }
// }
// console.log(sumTo(4))


// Сделать счетчик

// function makeCounter() {
//    let count = 0;
 
//    return function() {
//      return count++; // есть доступ к внешней переменной "count"
//    };
// }



// function mainCounter(count, value, interval){

//    let firstInterval = setInterval(function messege(){
//       if(count <= value){
//          return console.log(count++)
//       }
//       else{
//          clearInterval(firstInterval)
//          console.log('incorrect value')
//       }
//    }, interval)
// }
// mainCounter(0, 10, 100)


let range = {
   from: 1,
   to: 5
 };
 
 // 1. вызов for..of сначала вызывает эту функцию
 range[Symbol.iterator] = function() {
 
   // ...она возвращает объект итератора:
   // 2. Далее, for..of работает только с этим итератором, запрашивая у него новые значения
   return {
     current: this.from,
     last: this.to,
 
     // 3. next() вызывается на каждой итерации цикла for..of
     next() {
       // 4. он должен вернуть значение в виде объекта {done:.., value :...}
       if (this.current <= this.last) {
         return { done: false, value: this.current++ };
       } else {
         return { done: true };
       }
     }
   };
 };
 
 // теперь работает!
 for (let num of range) {
   console.log(num); // 1, затем 2, 3, 4, 5
 }